## rvx_devkit

1. source ${RVX_SHARED_HOME}/rvx_setup.sh
2. make config
